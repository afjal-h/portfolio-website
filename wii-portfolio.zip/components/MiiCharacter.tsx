import React from 'react';

const MiiCharacter: React.FC = () => {
  return (
    // Scaled using vh to maintain proportion with the TV interface
    // Hidden on mobile (hidden) / Visible on desktop (md:flex)
    <div className="hidden md:flex w-[50vh] h-[50vh] pointer-events-none items-end justify-center">
      <video
        // Ensure you have a file named 'mii.webm' in your public folder
        src="/mii.webm"
        autoPlay
        loop
        muted
        playsInline
        className="w-full h-full object-contain drop-shadow-2xl"
        // Ensure transparency is respected
        style={{ backgroundColor: 'transparent' }}
      />
    </div>
  );
};

export default MiiCharacter;